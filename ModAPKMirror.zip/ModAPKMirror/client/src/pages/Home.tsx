import { useState } from "react";
import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import SectionHeader from "@/components/SectionHeader";
import AppCard from "@/components/AppCard";
import FeaturedCard from "@/components/FeaturedCard";
import CategoryFilter from "@/components/CategoryFilter";

import netflixIcon from '@assets/generated_images/Netflix_app_icon_202d6578.png';
import youtubeIcon from '@assets/generated_images/YouTube_Premium_icon_dc3d3052.png';
import actionGameIcon from '@assets/generated_images/Action_RPG_game_icon_7b80c1f9.png';
import instagramIcon from '@assets/generated_images/Instagram_app_icon_56df656a.png';
import puzzleIcon from '@assets/generated_images/Puzzle_game_icon_573d1ea3.png';
import photoEditorIcon from '@assets/generated_images/Photo_editor_icon_bc324e1c.png';

export default function Home() {
  const [activeCategory, setActiveCategory] = useState("All");
  
  const gameCategories = ["All", "Action", "Adventure", "Puzzle", "RPG", "Sports", "Strategy"];
  const appCategories = ["All", "Social", "Photography", "Entertainment", "Tools", "Education"];

  const featuredApps = [
    {
      name: "YouTube Premium",
      rating: 4.9,
      description: "Enjoy ad-free videos, background playback, and offline downloads with YouTube Premium MOD",
      version: "v19.04.37",
      size: "118 MB",
      imageUrl: youtubeIcon,
    },
    {
      name: "Netflix Premium",
      rating: 4.8,
      description: "Stream unlimited movies and TV shows in HD quality with all premium features unlocked",
      version: "v8.102.0",
      size: "95 MB",
      imageUrl: netflixIcon,
    },
    {
      name: "Instagram Pro",
      rating: 4.7,
      description: "Enhanced Instagram with download features, ghost mode, and advanced privacy controls",
      version: "v320.0.0",
      size: "78 MB",
      imageUrl: instagramIcon,
    },
  ];

  const updatedGames = [
    {
      name: "Shadow Legends",
      category: "Action",
      rating: 4.6,
      description: "Epic action RPG with stunning graphics and unlimited resources for the ultimate gaming experience",
      version: "v2.16.2",
      size: "217 MB",
      imageUrl: actionGameIcon,
      modType: "MOD Menu/Unlimited Money",
      isUpdated: true,
    },
    {
      name: "Garden Quest",
      category: "Puzzle",
      rating: 4.5,
      description: "Match-3 puzzle adventure with unlimited lives and boosters to help you complete all levels",
      version: "v9.1.0",
      size: "140 MB",
      imageUrl: puzzleIcon,
      modType: "Unlimited Lives/Coins",
      isUpdated: true,
    },
    {
      name: "Epic Warriors",
      category: "RPG",
      rating: 4.8,
      description: "Fantasy RPG with auto-battle system and premium features completely unlocked",
      version: "v3.2.1",
      size: "320 MB",
      imageUrl: actionGameIcon,
      modType: "Premium Unlocked",
      isUpdated: true,
    },
    {
      name: "Dream Garden",
      category: "Casual",
      rating: 4.3,
      description: "Build your dream garden with unlimited resources and exclusive decorations",
      version: "v1.8.5",
      size: "145 MB",
      imageUrl: puzzleIcon,
      modType: "Unlimited Resources",
      isUpdated: true,
    },
  ];

  const updatedApps = [
    {
      name: "PhotoPro Editor",
      category: "Photography",
      rating: 4.7,
      description: "Professional photo editing with all premium filters and tools unlocked for free",
      version: "v12.7.6",
      size: "93 MB",
      imageUrl: photoEditorIcon,
      modType: "Premium Unlocked",
      isUpdated: true,
    },
    {
      name: "InstaPlus",
      category: "Social",
      rating: 4.5,
      description: "Enhanced Instagram experience with story downloader and ghost mode enabled",
      version: "v320.1.0",
      size: "82 MB",
      imageUrl: instagramIcon,
      modType: "Pro Features",
      isUpdated: true,
    },
    {
      name: "StreamFlix",
      category: "Entertainment",
      rating: 4.9,
      description: "Watch unlimited content with no ads and offline download capability",
      version: "v8.105.0",
      size: "98 MB",
      imageUrl: netflixIcon,
      modType: "Premium/No Ads",
      isUpdated: true,
    },
    {
      name: "TubePro",
      category: "Entertainment",
      rating: 4.8,
      description: "YouTube with background play, ad-free experience, and picture-in-picture mode",
      version: "v19.05.40",
      size: "125 MB",
      imageUrl: youtubeIcon,
      modType: "Premium Features",
      isUpdated: true,
    },
  ];

  const newGames = [
    {
      name: "Pixel Warriors",
      category: "Action",
      rating: 4.4,
      description: "Retro-style action game with modern gameplay and unlimited power-ups",
      version: "v1.2.51",
      size: "210 MB",
      imageUrl: actionGameIcon,
      modType: "MOD MENU/God Mode",
      isUpdated: false,
    },
    {
      name: "Puzzle Master",
      category: "Puzzle",
      rating: 4.6,
      description: "Brain-teasing puzzles with unlimited hints and ad-free gameplay",
      version: "v3.1.0",
      size: "85 MB",
      imageUrl: puzzleIcon,
      modType: "Unlimited Hints",
      isUpdated: false,
    },
    {
      name: "Quest Adventure",
      category: "Adventure",
      rating: 4.7,
      description: "Open-world adventure with unlocked premium content and resources",
      version: "v2.0.8",
      size: "450 MB",
      imageUrl: actionGameIcon,
      modType: "Full Game Unlocked",
      isUpdated: false,
    },
    {
      name: "Racing Pro",
      category: "Sports",
      rating: 4.5,
      description: "Ultimate racing experience with all cars unlocked and unlimited cash",
      version: "v5.4.2",
      size: "380 MB",
      imageUrl: puzzleIcon,
      modType: "Unlimited Money",
      isUpdated: false,
    },
  ];

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      
      <main className="mx-auto max-w-7xl px-6 py-12 space-y-16">
        <section>
          <SectionHeader title="Featured" />
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {featuredApps.map((app) => (
              <FeaturedCard key={app.name} {...app} />
            ))}
          </div>
        </section>

        <section>
          <SectionHeader title="Updated Games" viewAllLink="/games" />
          <div className="mb-6">
            <CategoryFilter
              categories={gameCategories}
              activeCategory={activeCategory}
              onCategoryChange={setActiveCategory}
            />
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {updatedGames.map((game) => (
              <AppCard key={game.name} {...game} />
            ))}
          </div>
        </section>

        <section>
          <SectionHeader title="Updated Apps" viewAllLink="/apps" />
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {updatedApps.map((app) => (
              <AppCard key={app.name} {...app} />
            ))}
          </div>
        </section>

        <section>
          <SectionHeader title="New Games" viewAllLink="/games?sort=latest" />
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {newGames.map((game) => (
              <AppCard key={game.name} {...game} />
            ))}
          </div>
        </section>
      </main>

      <footer className="border-t border-border mt-16 py-8">
        <div className="mx-auto max-w-7xl px-6 text-center text-sm text-muted-foreground">
          <p>© 2025 GetModsAPK. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}
