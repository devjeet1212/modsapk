import { ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";

interface SectionHeaderProps {
  title: string;
  viewAllLink?: string;
}

export default function SectionHeader({ title, viewAllLink }: SectionHeaderProps) {
  return (
    <div className="flex items-center justify-between mb-6">
      <h2 className="text-2xl font-bold" data-testid={`text-section-${title.toLowerCase().replace(/\s/g, '-')}`}>
        {title}
      </h2>
      {viewAllLink && (
        <Button variant="ghost" size="sm" data-testid={`button-view-all-${title.toLowerCase().replace(/\s/g, '-')}`}>
          View All
          <ChevronRight className="ml-1 h-4 w-4" />
        </Button>
      )}
    </div>
  );
}
