import { useState } from 'react';
import CategoryFilter from '../CategoryFilter';

export default function CategoryFilterExample() {
  const [activeCategory, setActiveCategory] = useState("All");
  const categories = ["All", "Action", "Adventure", "Puzzle", "RPG", "Sports", "Strategy"];

  return (
    <div className="p-6 bg-background">
      <CategoryFilter
        categories={categories}
        activeCategory={activeCategory}
        onCategoryChange={setActiveCategory}
      />
    </div>
  );
}
