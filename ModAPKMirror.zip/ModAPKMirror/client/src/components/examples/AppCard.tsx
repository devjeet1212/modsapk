import AppCard from '../AppCard';
import netflixIcon from '@assets/generated_images/Netflix_app_icon_202d6578.png';

export default function AppCardExample() {
  return (
    <div className="p-6 bg-background">
      <AppCard
        name="Netflix Premium"
        category="Entertainment"
        rating={4.8}
        description="Watch unlimited movies and TV shows with premium features unlocked"
        version="v8.102.0"
        size="95 MB"
        imageUrl={netflixIcon}
        modType="Premium Unlocked"
        isUpdated={true}
      />
    </div>
  );
}
