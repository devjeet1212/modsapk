import FeaturedCard from '../FeaturedCard';
import youtubeIcon from '@assets/generated_images/YouTube_Premium_icon_dc3d3052.png';

export default function FeaturedCardExample() {
  return (
    <div className="p-6 bg-background">
      <FeaturedCard
        name="YouTube Premium"
        rating={4.9}
        description="Enjoy ad-free videos, background playback, and offline downloads with YouTube Premium MOD"
        version="v19.04.37"
        size="118 MB"
        imageUrl={youtubeIcon}
      />
    </div>
  );
}
