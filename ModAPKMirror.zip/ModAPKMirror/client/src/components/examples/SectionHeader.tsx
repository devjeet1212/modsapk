import SectionHeader from '../SectionHeader';

export default function SectionHeaderExample() {
  return (
    <div className="p-6 bg-background">
      <SectionHeader title="Featured Games" viewAllLink="/games" />
    </div>
  );
}
