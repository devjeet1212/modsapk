import { type App, type InsertApp } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getApp(id: string): Promise<App | undefined>;
  getAllApps(): Promise<App[]>;
  getAppsByType(type: string): Promise<App[]>;
  createApp(app: InsertApp): Promise<App>;
}

export class MemStorage implements IStorage {
  private apps: Map<string, App>;

  constructor() {
    this.apps = new Map();
  }

  async getApp(id: string): Promise<App | undefined> {
    return this.apps.get(id);
  }

  async getAllApps(): Promise<App[]> {
    return Array.from(this.apps.values());
  }

  async getAppsByType(type: string): Promise<App[]> {
    return Array.from(this.apps.values()).filter((app) => app.type === type);
  }

  async createApp(insertApp: InsertApp): Promise<App> {
    const id = randomUUID();
    const app: App = { ...insertApp, id, downloads: insertApp.downloads ?? 0 };
    this.apps.set(id, app);
    return app;
  }
}

export const storage = new MemStorage();
