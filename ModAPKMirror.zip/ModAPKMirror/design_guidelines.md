# Design Guidelines for MOD APK Showcase Platform

## Design Approach: Hybrid Reference-Based

**Primary References:** Google Play Store (structure) + Netflix (dark theme & card layouts) + Spotify (content organization)

This utility-focused platform prioritizes content discovery while maintaining visual appeal through dark aesthetics and clear information hierarchy.

## Core Design Elements

### A. Color Palette

**Dark Mode Foundation:**
- Background Primary: 12 8% 8% (deep charcoal)
- Background Secondary: 12 8% 12% (elevated surfaces)
- Background Tertiary: 12 8% 16% (cards/panels)

**Brand & Accent:**
- Primary Purple: 270 65% 58% (vibrant purple for CTAs and highlights)
- Secondary Pink: 330 70% 62% (accent for badges and interactions)
- Success Green: 142 71% 45% (ratings, download indicators)

**Semantic Colors:**
- Text Primary: 0 0% 95% (main content)
- Text Secondary: 0 0% 65% (metadata, descriptions)
- Text Tertiary: 0 0% 45% (subtle info)
- Border: 0 0% 20% (dividers, card outlines)

### B. Typography

**Font Stack:** 
- Primary: 'Inter' or 'SF Pro Display' via Google Fonts
- Fallback: system-ui, -apple-system, sans-serif

**Scale:**
- Hero/H1: 48px/56px, bold (800)
- H2/Section Titles: 32px/40px, bold (700)
- H3/Card Titles: 20px/28px, semibold (600)
- Body: 16px/24px, regular (400)
- Meta/Small: 14px/20px, medium (500)
- Labels/Badges: 12px/16px, semibold (600)

### C. Layout System

**Spacing Primitives:** Tailwind units of 2, 4, 6, 8, 12, 16 (e.g., p-4, gap-6, mb-8)

**Grid Structure:**
- Desktop: 4-column grid for app cards (grid-cols-1 md:grid-cols-2 lg:grid-cols-4)
- Container: max-w-7xl with px-6 padding
- Card spacing: gap-6 between items
- Section spacing: py-16 for major sections, py-8 for subsections

### D. Component Library

**Navigation:**
- Sticky header with dark blur background (backdrop-blur-xl bg-background/80)
- Logo left, centered search bar, category dropdowns, mobile hamburger
- Height: h-16 with smooth shadow on scroll

**Hero Section:**
- Full-width gradient background (purple to pink gradient overlay on dark base)
- Centered search bar (max-w-2xl) with icon, placeholder text
- "Recent Searches" pills below with app thumbnails and quick links
- Height: 60vh minimum

**App/Game Cards:**
- Aspect ratio 16:9 thumbnail image with rounded corners (rounded-xl)
- MOD badge overlay (top-right, purple/pink gradient, text-xs)
- Content section: title (truncate-2-lines), rating stars, category tag
- Meta info: version number, file size, in smaller text
- Download button: full-width, primary purple, rounded-lg
- Card hover: subtle lift (scale-105) with glow effect

**Category Sections:**
- Section header with title + "View All" link
- Horizontal scrollable on mobile, grid on desktop
- Clear visual separation with border-t

**Filtering & Sorting:**
- Pill-style category filters (border, hover fills)
- Dropdown for sort options (Latest, Updated, Popular)
- Active state: filled with primary color

**Badges:**
- MOD types: distinct colors (Unlimited Money: gold, Premium: purple, No Ads: green)
- Rounded-full with px-3 py-1 sizing
- Text-xs weight-semibold

### E. Images

**Hero Background:**
- Abstract tech/gaming pattern or gradient mesh
- Dark overlay to ensure text readability
- Subtle animated gradient (if performance allows)

**App Thumbnails:**
- Required for all app cards (placeholder if missing)
- Optimized WebP format
- Lazy loading for performance

**Content Images:**
- Featured section: high-quality app screenshots
- Category icons: minimal line icons (white/purple)

## Key Design Patterns

**Information Hierarchy:**
1. App thumbnail (most prominent)
2. App title + rating
3. Short description (2 lines max)
4. Technical specs (version, size)
5. Download CTA

**Interactive States:**
- Cards: hover shadow-xl, transform scale-105, transition-all duration-300
- Buttons: hover brightness-110, active scale-95
- Links: hover text-primary underline

**MOD Indicators:**
- Always visible badge on thumbnail
- Color-coded by mod type
- Consistent placement (top-right corner)

**Responsive Behavior:**
- Mobile: Single column, bottom sheet for filters
- Tablet: 2-column grid
- Desktop: 4-column grid with sidebar filters

## Performance Considerations

- Use CDN for icons (Heroicons via CDN)
- Lazy load images below fold
- Virtualize long lists if >50 items
- Skeleton loaders during content fetch

## Accessibility

- Maintain WCAG AA contrast ratios (especially on dark backgrounds)
- Keyboard navigation for all interactive elements
- Clear focus indicators (ring-2 ring-primary)
- Alt text for all app thumbnails